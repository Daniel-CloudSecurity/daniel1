import React from 'react';
import logo2 from '../../public/owasp.jpg';

const Home = () => {
    return (
        <React.Fragment>
            <main role="main" className="container starter-template">
            <hr/>
            <img src={logo2} alt="" />
            </main>
        </React.Fragment>
  );
}

export default Home;
